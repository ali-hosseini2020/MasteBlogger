﻿namespace MB.Application.Contracts.ArticleCategory
{
    public class CreateArticleCategory
    {
        public string Title { get; set; }


    }
}
