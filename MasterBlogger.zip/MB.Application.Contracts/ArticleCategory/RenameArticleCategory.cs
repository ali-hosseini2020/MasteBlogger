﻿namespace MB.Application.Contracts.ArticleCategory
{
   public class RenameArticleCategory : CreateArticleCategory
    {
        public long Id { get; set; }
    }
}