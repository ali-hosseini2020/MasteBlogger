﻿using System.Collections.Generic;

namespace Mb.Domain.ArticleCategoryAgg
{
   public interface IArticleCategoryRepository
   {
       List<ArticleCategory> GetAll();

       void Add(ArticleCategory entity);

   }
}
