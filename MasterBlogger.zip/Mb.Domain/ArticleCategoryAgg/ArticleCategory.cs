﻿using System;

namespace Mb.Domain.ArticleCategoryAgg
{
   public class ArticleCategory
    {
        public long Id { get; private set; }
        public string Title { get; private set; }
        public bool IsDeleted { get; private set; }
        public DateTime CreationDate { get; private set; }
        
        public ArticleCategory(string title)
        {
            Title = title;
            IsDeleted = false; // So, when we create the desired record at the beginning, it hasn't been deleted.Initializes the record as active (not soft-deleted).
            CreationDate = DateTime.Now; // The date our target record is created
        }
    }
}